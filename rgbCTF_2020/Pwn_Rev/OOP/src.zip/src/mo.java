public class mo {

public String fd() { 
 return "mv";
}

public String fn() { 
 return "va";
}

public String ny() { 
 return "yo";
}

public String pb() { 
 return "zt";
}

public String vk() { 
 return "si";
}

public String sh() { 
 return "jy";
}

public String zd() { 
 return "al";
}

public String iq() { 
 return "eb";
}

public String yo() { 
 return "qm";
}

public String uw() { 
 return "ny";
}

public String ai() { 
 return "um";
}

public String ez() { 
 return "ut";
}

public String zw() { 
 return "ex";
}

public String eu() { 
 return "ym";
}

public String hk() { 
 return "vn";
}

}