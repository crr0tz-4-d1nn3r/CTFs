public class qa {

public String go() { 
 return "kz";
}

public String bl() { 
 return "pu";
}

public String dp() { 
 return "gs";
}

public String zo() { 
 return "gi";
}

public String rc() { 
 return "tp";
}

public String di() { 
 return "cy";
}

public String gb() { 
 return "tu";
}

public String ah() { 
 return "xk";
}

public String nd() { 
 return "ne";
}

public String cr() { 
 return "do";
}

public String bj() { 
 return "nd";
}

public String zc() { 
 return "de";
}

public String wq() { 
 return "bj";
}

public String ft() { 
 return "fv";
}

public String az() { 
 return "qj";
}

}