public class iy {

public String yn() { 
 return "fw";
}

public String er() { 
 return "ga";
}

public String rv() { 
 return "pe";
}

public String eq() { 
 return "je";
}

public String au() { 
 return "ns";
}

public String uc() { 
 return "yn";
}

public String fw() { 
 return "vi";
}

public String nz() { 
 return "jr";
}

public String lb() { 
 return "fl";
}

public String pv() { 
 return "ie";
}

public String ew() { 
 return "ly";
}

public String ag() { 
 return "gj";
}

public String np() { 
 return "re";
}

public String rz() { 
 return "mh";
}

public String le() { 
 return "ze";
}

}