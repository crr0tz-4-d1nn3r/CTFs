public class gq {

public String ur() { 
 return "pn";
}

public String aq() { 
 return "la";
}

public String yv() { 
 return "lh";
}

public String vf() { 
 return "aq";
}

public String hn() { 
 return "st";
}

public String nk() { 
 return "wh";
}

public String oi() { 
 return "vq";
}

public String qw() { 
 return "yz";
}

public String wt() { 
 return "vf";
}

public String jo() { 
 return "or";
}

public String ba() { 
 return "uy";
}

public String ub() { 
 return "oc";
}

public String hg() { 
 return "ov";
}

public String ca() { 
 return "wl";
}

public String bi() { 
 return "gn";
}

}