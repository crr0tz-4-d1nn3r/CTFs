public class bv {

public String ni() { 
 return "ls";
}

public String rm() { 
 return "lg";
}

public String gz() { 
 return "rl";
}

public String za() { 
 return "jv";
}

public String qe() { 
 return "ux";
}

public String eg() { 
 return "fp";
}

public String bm() { 
 return "hj";
}

public String ue() { 
 return "wd";
}

public String jh() { 
 return "lj";
}

public String wk() { 
 return "za";
}

public String nv() { 
 return "ja";
}

public String wp() { 
 return "wk";
}

public String zs() { 
 return "be";
}

public String dk() { 
 return "ht";
}

public String yk() { 
 return "fo";
}

}