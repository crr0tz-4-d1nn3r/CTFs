public class gx {

public String jp() { 
 return "uo";
}

public String ra() { 
 return "so";
}

public String ay() { 
 return "qv";
}

public String vs() { 
 return "qf";
}

public String yh() { 
 return "zh";
}

public String ae() { 
 return "hd";
}

public String ge() { 
 return "kl";
}

public String ok() { 
 return "ul";
}

public String sp() { 
 return "bt";
}

public String fz() { 
 return "tj";
}

public String lw() { 
 return "jl";
}

public String sv() { 
 return "zg";
}

public String rg() { 
 return "ek";
}

public String nq() { 
 return "sn";
}

public String uo() { 
 return "rg";
}

}