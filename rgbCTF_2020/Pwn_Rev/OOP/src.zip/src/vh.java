public class vh {

public String ck() { 
 return "ea";
}

public String kf() { 
 return "mp";
}

public String tq() { 
 return "gf";
}

public String gr() { 
 return "pg";
}

public String bs() { 
 return "il";
}

public String cu() { 
 return "lq";
}

public String ac() { 
 return "fc";
}

public String db() { 
 return "up";
}

public String xv() { 
 return "py";
}

public String xo() { 
 return "us";
}

public String mr() { 
 return "pa";
}

public String sk() { 
 return "ua";
}

public String nt() { 
 return "nt";
}

public String ry() { 
 return "qo";
}

public String kv() { 
 return "rk";
}

}