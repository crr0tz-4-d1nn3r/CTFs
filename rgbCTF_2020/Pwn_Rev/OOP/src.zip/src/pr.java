public class pr {

public String wa() { 
 return "nm";
}

public String pk() { 
 return "te";
}

public String gh() { 
 return "me";
}

public String lf() { 
 return "ix";
}

public String to() { 
 return "ib";
}

public String te() { 
 return "wj";
}

public String mk() { 
 return "ta";
}

public String my() { 
 return "yd";
}

public String ys() { 
 return "df";
}

public String wj() { 
 return "va";
}

public String ti() { 
 return "is";
}

public String tr() { 
 return "xz";
}

public String wy() { 
 return "ms";
}

public String dq() { 
 return "xl";
}

public String rt() { 
 return "gc";
}

}