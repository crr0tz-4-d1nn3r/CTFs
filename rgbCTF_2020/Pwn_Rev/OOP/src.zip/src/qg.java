public class qg {

public String pm() { 
 return "gp";
}

public String mb() { 
 return "ut";
}

public String yi() { 
 return "zm";
}

public String ng() { 
 return "vy";
}

public String ro() { 
 return "dn";
}

public String dz() { 
 return "im";
}

public String qp() { 
 return "ty";
}

public String am() { 
 return "xs";
}

public String xs() { 
 return "mb";
}

public String pt() { 
 return "uf";
}

public String iz() { 
 return "fs";
}

public String ak() { 
 return "qr";
}

public String vd() { 
 return "tk";
}

public String kr() { 
 return "uh";
}

public String rq() { 
 return "bx";
}

}